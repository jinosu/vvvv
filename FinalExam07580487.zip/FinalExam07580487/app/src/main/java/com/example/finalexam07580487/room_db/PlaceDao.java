package com.example.finalexam07580487.room_db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.finalexam07580487.model.Place;

import java.util.List;



@Dao
public interface PlaceDao {

    @Query("SELECT * FROM place")
    List<Place> getAllPlace();

    @Insert
    void insertPlace(Place place);
}
