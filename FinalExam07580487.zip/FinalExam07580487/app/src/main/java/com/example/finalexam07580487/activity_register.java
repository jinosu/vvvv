package com.example.finalexam07580487;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalexam07580487.model.Place;
import com.example.finalexam07580487.room_db.LedgerRepository;

import java.util.List;

public class activity_register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final Button addPlaceButton = findViewById(R.id.register_button);
        addPlaceButton.setOnClickListener(new View.OnClickListener() {
            Handler handler = new  Handler();
            @Override
            public void onClick(View v) {

                EditText placeNameEditText = findViewById(R.id.full_name_edit_text);
                String name = placeNameEditText.getText().toString();
                EditText placeNameEditText2 = findViewById(R.id.username_edit_text);
                String str = placeNameEditText2.getText().toString();
                EditText placeNameEditText3 = findViewById(R.id.password_edit_text);
                String p = placeNameEditText3.getText().toString();
                if(name.length()!=0&&str.length()!=0&&p.length()!=0) {
                    Place place = new Place(0, name, str, p);

                    insertPlace(place);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Intent intent = new Intent( activity_register.this,activity_login.class );//เรียกหน้า
                        startActivity(intent);
                        finish();
                        Toast.makeText(activity_register.this,"Register successfully",Toast.LENGTH_SHORT ).show();
                    }
                }, 1000);}
                else{
                    Toast.makeText(activity_register.this,"All fields are required",Toast.LENGTH_SHORT ).show();
                }
            }
        });
    }
    private void insertPlace(Place item) {
        LedgerRepository repo = new LedgerRepository(activity_register.this);
        repo.insertLedger(item, new LedgerRepository.InsertCallback() {
            @Override
            public void onInsertSuccess() {
                finish();
            }
        });
    }
    private void reloadData() {
        LedgerRepository repo = new LedgerRepository(activity_register.this);

        repo.getLedger(new LedgerRepository.Callback() {
            @Override
            public void onGetLedger(List<Place> itemList) {
                int totalAmount = 0;

                for (Place item: itemList) {
                    totalAmount += item.id;
                }
            }
        });
        {


            //  TextView balanceTextView = findViewById(R.id.balance_text_view);
            // balanceTextView.setText("คงเหลือ ".concat(String.valueOf(totalAmount)).concat(" บาท"));

            //  RecyclerView recyclerView = findViewById(R.id.ledger_recycler_view);
            // LedgerRecyclerViewAdapter adapter = new LedgerRecyclerViewAdapter(
            //          MainActivity.this,
            //           R.layout.item_ledger,
            //            itemList
            //  );
            //  recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            //  recyclerView.setAdapter(adapter);

        }}

}
