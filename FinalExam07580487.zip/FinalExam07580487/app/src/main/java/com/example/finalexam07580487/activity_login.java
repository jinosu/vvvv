package com.example.finalexam07580487;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.finalexam07580487.db.DatabaseHelper;
import com.example.finalexam07580487.model.Place;

public class activity_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.d("user","user");
        final Button addPlaceButton = findViewById(R.id.register_button);
        addPlaceButton.setOnClickListener(new View.OnClickListener() {
            Handler handler = new  Handler();
            @Override
            public void onClick(View v) {

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        Intent intent = new Intent( activity_login.this, activity_register.class);//เรียกหน้า
                        startActivity(intent);
                        finish();
                    }
                }, 0);
            }
        });
    }


}
