package com.example.finalexam07580487.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.finalexam07580487.model.Place;

import java.util.List;

import com.example.finalexam07580487.R;

public class PlaceListAdapter extends ArrayAdapter<Place> {

    private Context mContext;
    private int mResource;
    private List<Place> mPlaceList;

    public PlaceListAdapter(@NonNull Context context, int resource, @NonNull List<Place> placeList) {
        super(context, resource, placeList);
        this.mContext = context;
        this.mResource = resource;
        this.mPlaceList = placeList;
    }


}








